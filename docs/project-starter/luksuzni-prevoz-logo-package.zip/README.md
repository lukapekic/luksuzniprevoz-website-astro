# Luksuzni Prevoz Logo Package

Included assets:
- Full logo: light and dark versions in SVG, PNG, WEBP
- Symbol / icon only: light and dark versions in SVG, PNG, WEBP
- Favicon and common web / manifest icons
- Preview boards for light and dark presentation
- site.webmanifest

Color guidance:
- `logo-full-dark.*` and `symbol-dark.*` are intended for dark backgrounds.
- `logo-full-light.*` and `symbol-light.*` are intended for light backgrounds.
