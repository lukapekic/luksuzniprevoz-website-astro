# Private Chauffeur — Localized UI Contract Addendum

Status: approved implementation input

No blueprint change is required. The locked page structure remains valid.

Merge these semantic keys into `src/content/ui/{sr,en,ru}.json` with locale parity:

- `booking.minimum`
- `booking.included`
- `service.privateChauffeur.chauffeurAvailable`
- `service.privateChauffeur.multiDayQuote`
- `service.privateChauffeur.internationalQuote`
- `service.privateChauffeur.complexQuote`

Continue to reuse existing:
- `booking.mode.hourly`
- `booking.mode.halfDay`
- `booking.mode.fullDay`
- `booking.upTo`
- `booking.unit.hours`
- `booking.unit.km`

Rules:
- numbers for minimum hours / half-day / full-day / included kilometres come from `services.ts`;
- translations provide presentation wording only;
- do not hardcode fare values or currency;
- do not translate internal enum codes directly in the component;
- ServiceStandards continues to use the shared `operations.*` localization contract already established for Airport.
