/**
 * theme:sync — CLI script to generate CSS from theme tokens.
 * FND-THEME-07
 *
 * Usage: pnpm theme:sync [path/to/project]
 *   If no path is given, defaults to examples/reference-site.
 *   Writes to <project>/src/theme/generated/theme.css.
 *   Also writes to packages/astro-foundation/src/theme/generated/theme.css as default.
 */

import { resolve, join } from "node:path";
import { writeFileSync, mkdirSync, existsSync } from "node:fs";
import { loadThemeTokens } from "../packages/astro-foundation/src/theme/loader.ts";
import { ACTIVE_THEME_VERSION } from "../packages/astro-foundation/src/theme/active-theme.ts";
import { generateThemeCss } from "../packages/astro-foundation/src/theme/sync.ts";
import { formatIssues } from "../packages/astro-foundation/src/core/errors.ts";
import { validateThemeSemantics } from "../packages/astro-foundation/src/theme/validate-theme.ts";

const args = process.argv.slice(2);
const projectPath = args[0] || "examples/reference-site";
const rootDir = resolve(import.meta.dirname ?? ".", "..");
const absProjectPath = resolve(rootDir, projectPath);

// Resolve the active theme version from the target project's foundation.config.ts
// (the per-project selector also read by types:generate), falling back to the
// core ACTIVE_THEME_VERSION constant. This lets each consumer site pin its own
// active version while the core constant remains the shared default — so syncing
// the reference site still resolves its v1, and syncing the luksuzni site
// resolves its v2.
async function resolveActiveThemeVersion(projectDir: string): Promise<string> {
  for (const p of [
    join(projectDir, "foundation.config.ts"),
    join(projectDir, "src", "foundation.config.ts"),
  ]) {
    if (!existsSync(p)) continue;
    try {
      const mod = await import(p);
      const cfg = mod.default ?? mod["config"];
      if (cfg && typeof cfg.activeThemeVersion === "string" && cfg.activeThemeVersion) {
        return cfg.activeThemeVersion;
      }
    } catch {
      // Fall through to the core constant on any config load failure.
    }
  }
  return ACTIVE_THEME_VERSION;
}

const activeThemeVersion = await resolveActiveThemeVersion(absProjectPath);
const themeVersionDir = join(absProjectPath, "src", "theme", "versions", activeThemeVersion);

console.log(`Loading theme tokens from: ${themeVersionDir}`);

const { tokens, issues } = loadThemeTokens({ themeDir: themeVersionDir });

if (issues.length > 0) {
  console.error(formatIssues(issues));
  process.exit(1);
}

// Run semantic validation (warnings only — sync still proceeds)
const semanticIssues = validateThemeSemantics(tokens);
if (semanticIssues.length > 0) {
  console.warn(formatIssues(semanticIssues));
  console.warn("Semantic issues found but proceeding with CSS generation.");
}

const css = generateThemeCss(tokens);

// Write to project
const projectOutput = join(absProjectPath, "src", "theme", "generated", "theme.css");
mkdirSync(join(projectOutput, ".."), { recursive: true });
writeFileSync(projectOutput, css, "utf-8");
console.log(`✓ Wrote ${projectOutput}`);

// Write to core package default ONLY when syncing the reference site (the core's
// own default consumer). Syncing a product site (e.g. luksuzni-prevoz) must NOT
// mutate the core generated CSS — otherwise the core file represents "the last
// project synced" rather than the reference site's validated tokens.
const referenceSiteDir = resolve(rootDir, "examples", "reference-site");
const isReferenceSite = absProjectPath === referenceSiteDir ||
  absProjectPath === resolve(referenceSiteDir);
if (isReferenceSite) {
  const coreOutput = join(
    rootDir,
    "packages",
    "astro-foundation",
    "src",
    "theme",
    "generated",
    "theme.css",
  );
  mkdirSync(join(coreOutput, ".."), { recursive: true });
  writeFileSync(coreOutput, css, "utf-8");
  console.log(`✓ Wrote ${coreOutput}`);
} else {
  console.log(`⊘ Skipped core package write (not the reference site).`);
}

console.log(
  `\nTheme "${tokens.manifest.name}" v${tokens.manifest.themeVersion} synced successfully.`,
);
